package prova;

public class Departamento {  
    public String name;
    protected int qtdFun;
    
    
    
    protected void exibirNome(){
        
    };
    
    protected String CadasFun(String nome){
    
        return nome; 
    };
}
