package prova3;
public class Atendimento {
    public Atendimento() {
    }
   
    
   public void TipoAte(){
       System.out.println("Gustavo!!");
   }
   
   
   
   
   
   

}
